package com.example.spring.com.example.spring;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {
	
	
	//GET HTTP METHOD
	//http://loalhost:8080/hello-tutorial

	@GetMapping("/hello-tutorial")
	public String helloWorld() {
		return "Hello World!";
	}
}
