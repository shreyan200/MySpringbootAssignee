package com.example.spring.com.example.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

//http:localhost:8080/studentname	
	
@GetMapping("/studentname")	
public Student getStudent() {
	return new Student("Paul","Pummy");
}

@GetMapping("/studentsname")
public List<Student>getStudents(){
	List<Student>s=new ArrayList<>();
	s.add(new Student("Patel","Avirag"));
	s.add(new Student("Dey","Sirag"));
	s.add(new Student("Shah","Payel"));
	s.add(new Student("Roy","Pooja"));
	s.add(new Student("Rai","Priti"));
	s.add(new Student("Sarkar","Patel"));
	return s;
}

@GetMapping("/student/{firstName}/{lastName}")
public Student studentPathVariable(@PathVariable("firstName") String firstName, @PathVariable("lastName") String lastName) {
	return new Student (firstName,lastName);
}



//build rest api to handle query parameters
@GetMapping("/studentparam")
public Student studentQueryParam(@RequestParam(name="firstName")String firstName,
		@RequestParam(name="lastName") String lastName) {
	return new Student(firstName,lastName);
}
	
}
